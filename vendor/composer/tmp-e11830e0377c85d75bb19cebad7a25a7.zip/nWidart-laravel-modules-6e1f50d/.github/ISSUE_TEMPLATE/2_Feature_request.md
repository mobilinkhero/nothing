---
name: "✨ Feature request"
about: 'Suggest a new feature or other improvements.'
labels: "feature request"

---

### Summary

<!--
Describe in detail what you propose, show (preferable) code examples and also signal if you're willing to work on it!
-->
