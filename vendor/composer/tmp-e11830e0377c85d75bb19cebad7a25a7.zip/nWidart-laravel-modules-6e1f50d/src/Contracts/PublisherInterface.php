<?php

namespace Nwidart\Modules\Contracts;

interface PublisherInterface
{
    /**
     * Publish something.
     */
    public function publish();
}
